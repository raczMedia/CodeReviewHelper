
let hovered_diff;
let pr = getParam('pull');
let preventStoring = false;

applyHeaderStyles();

setTimeout(function() {
    initSavedHighlights();
    initClosedDiffs();
}, 1500);

chrome.extension.onMessage.addListener(function(msg) {
    if (msg.action == 'toggle-diff-bookmark' && hovered_diff !== null) {
        let color = hovered_diff
            .querySelector('.js-details-target')
            .style.background == 'rgb(223, 255, 0)'
                ? 'transparent'
                : 'rgb(223, 255, 0)';

        hovered_diff.querySelector('.js-details-target').style.background = color;

        let diffTitle = hovered_diff.querySelector('.file-info a').getAttribute('title');

        if (color == 'rgb(223, 255, 0)') {
            addToStorage('savedHighlights', diffTitle);
        } else {
            removeFromStorage('savedHighlights', diffTitle);
        }
    }

    if (msg.action == 'toggle-diff-state' && hovered_diff !== null) {
        hovered_diff.querySelector('.js-details-target').click();
    }
});

document.querySelectorAll('.js-details-container').forEach((item) => {
    item.classList.add('has-listener');
    item.addEventListener('mouseenter', selectDiff);
});

document.querySelectorAll('.js-details-container').forEach((item) => {
    item.classList.add('has-listener');
    item.addEventListener('mouseleave', resetSelectedDiff);
});

document.addEventListener('mouseover', (e) => {
    if (e.target.classList.contains('js-details-container') && ! e.target.classList.contains('has-listener')) {
        assignMouseListeners(e.target);
    } else if (e.target.closest('.js-details-container') && ! e.target.closest('.js-details-container').classList.contains('has-listener')) {
        assignMouseListeners(e.target.closest('.js-details-container'));
    }
}, true);

document.addEventListener('click', (e) => {
    if (e.target.classList.contains('js-details-target')) {

        container = e.target.closest('.js-details-container');

        let diffTitle = container.querySelector('.file-info a').getAttribute('title');

        if (container.classList.contains('open')) {
            if (preventStoring == false) {
                removeFromStorage('closedDiffs', diffTitle);
            }
            container.scrollIntoView({block: "start"});

        } else {
            if (preventStoring == false) {
                addToStorage('closedDiffs', diffTitle);
            }

            let selectedDiff = document.querySelector('.selectedDiff');
            if (selectedDiff) {
                let nextDiff = selectedDiff.findSiblingByClass('open');
                if (! nextDiff) {
                    let nextSet = selectedDiff
                        .closest('.js-diff-progressive-container')
                        .findSiblingByClass('.js-diff-progressive-container');

                    if (nextSet && nextSet.querySelector('.js-details-container.open').length) {
                        nextDiff = nextSet.querySelector('.js-details-container.open');
                    }
                }

                if (nextDiff) {
                    nextDiff.scrollIntoView({block: "start"});
                    adjustScrolling(-50);
                }
            }
        }
    }
});

/*document.addEventListener('keypress', (e) => {
    if (e.keyCode == 8721) { // alt+w key aka ∑ - highlight
        if (hovered_diff !== null) {
            let color = hovered_diff
                .querySelector('.js-details-target')
                .style.background == 'rgb(223, 255, 0)'
                    ? 'transparent'
                    : 'rgb(223, 255, 0)';

            hovered_diff.querySelector('.js-details-target').style.background = color;

            let diffTitle = hovered_diff.querySelector('.file-info a').getAttribute('title');

            if (color == 'rgb(223, 255, 0)') {
                addToStorage('savedHighlights', diffTitle);
            } else {
                removeFromStorage('savedHighlights', diffTitle);
            }
        }
    }

    if (e.keyCode == 339) { // alt+q key aka œ - close section aka ∑
        if (hovered_diff !== null) {
        }
    }
});
*/

function initSavedHighlights() {
    savedHighlights = getLocalStorageParam('savedHighlights');

    if (savedHighlights) {
        savedHighlights.forEach(function (value) {
            let highlight = document.querySelector('.file-info a[title="'+value+'"]');

            if (highlight) {
                highlight.closest('.js-details-container')
                    .querySelector('.js-details-target')
                    .style.background = 'rgb(223, 255, 0)';
            }
        });
    }
}

function initClosedDiffs() {
    closedDiffs = getLocalStorageParam('closedDiffs');

    if (closedDiffs) {
        preventStoring = true;

        closedDiffs.forEach(function (value, key) {
            let link = document.querySelector('.file-info a[title="'+value+'"]');
            if (link) {
                link.closest('.js-details-container')
                .querySelector('.js-details-target')
                .click();
            }

            if (key + 1 == closedDiffs.length) {
                preventStoring = false;
            }
        });
    }
}

function getParam(param) {
    let paramValue = null;
    let list = window.location.pathname.split('/');

    list.forEach(function(value, key) {
        if (value == param) {
            paramValue = list[key + 1];
        }
    });

    return paramValue;
}

function getLocalStorageParam(param) {
    return JSON.parse(window.localStorage.getItem(`${param}.${pr}`));
}

function setLocalStorageParam(param, value) {
    window.localStorage.setItem(`${param}.${pr}`, JSON.stringify(value));
}

function addToStorage(storageKey, value) {
    let list = getLocalStorageParam(storageKey);

    if (list !== null) {
        list.push(value);
    } else {
        list = [value];
    }

    setLocalStorageParam(storageKey, list);
}

function removeFromStorage(storageKey, itemValue) {
    let list = getLocalStorageParam(storageKey);

    list = list.filter(function(value){
        return value != itemValue;
    });

    setLocalStorageParam(storageKey, list);
}

function adjustScrolling(amount) {
    document.querySelector('html').scrollTop += amount;
}

function assignMouseListeners(element) {
    element.classList.add('has-listener');
    element.addEventListener('mouseenter', selectDiff);
    element.addEventListener('mouseleave', resetSelectedDiff);
}

function applyHeaderStyles() {
    var ref = document.querySelector('script');
    var style = document.createElement('style');

    style.innerHTML =
        '.file-header.file-header--expandable.js-file-header {' +
            'position: sticky;' +
            'top: 60px;' +
            'z-index: 10;' +
        '}';

    ref.parentNode.insertBefore(style, ref);
}

function selectDiff () {
    if (! this.classList.contains('selectedDiff')) {
        this.classList.add('selectedDiff');
        hovered_diff = this;
    }
}

function resetSelectedDiff () {
    if (this.classList.contains('selectedDiff')) {
        hovered_diff = null;
        let selected = document.querySelector('.selectedDiff');
        if (selected) {
            selected.classList.remove('selectedDiff');
        }
    }
}

HTMLElement.prototype.findSiblingByClass = function(str) {
    let nextElement = this.nextElementSibling;

    if (nextElement) {
        if (nextElement.classList.contains(str)) {
            return nextElement;
        }

        return nextElement.findSiblingByClass(str);
    }

    return null;
};
